export type Status = "na_loja" | "em_rota" | "devolvida" | "quitada" | "agendada" | "cancelada";

export interface Ficha {
  id: string;
  customerCode: string;
  customerName: string;
  creationDate: Date;
  status: Status;
  observations: string;
  reschedule1?: Date;
  reschedule2?: Date;
  reschedule3?: Date;
}

export interface Customer {
  code: string;
  name: string;
}
