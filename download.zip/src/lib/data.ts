import type { Ficha, Customer } from './types';

export const customers: Customer[] = [
  { code: '001', name: 'João Silva' },
  { code: '002', name: 'Maria Oliveira' },
  { code: '003', name: 'José Santos' },
  { code: '004', name: 'Ana Costa' },
  { code: '005', name: 'Pedro Martins' },
];

const today = new Date();
const yesterday = new Date();
yesterday.setDate(today.getDate() - 1);
const twoDaysAgo = new Date();
twoDaysAgo.setDate(today.getDate() - 2);


export const fichas: Ficha[] = [
  {
    id: 'F001',
    customerCode: '001',
    customerName: 'João Silva',
    creationDate: twoDaysAgo,
    status: 'quitada',
    observations: 'Cliente satisfeito com o serviço.',
  },
  {
    id: 'F002',
    customerCode: '002',
    customerName: 'Maria Oliveira',
    creationDate: today,
    status: 'em_rota',
    observations: 'Em rota para entrega.',
  },
  {
    id: 'F003',
    customerCode: '003',
    customerName: 'José Santos',
    creationDate: today,
    status: 'na_loja',
    observations: 'Aguardando retirada pelo cobrador.',
  },
  {
    id: 'F004',
    customerCode: '004',
    customerName: 'Ana Costa',
    creationDate: yesterday,
    status: 'devolvida',
    observations: 'Endereço não localizado, devolvido à base.',
  },
  {
    id: 'F005',
    customerCode: '005',
    customerName: 'Pedro Martins',
    creationDate: today,
    status: 'agendada',
    observations: 'Reagendado para a próxima semana.',
    reschedule1: new Date(new Date().setDate(today.getDate() + 7)),
  },
    {
    id: 'F006',
    customerCode: '001',
    customerName: 'João Silva',
    creationDate: today,
    status: 'na_loja',
    observations: 'Nova cobrança para item devolvido.',
  },
];
