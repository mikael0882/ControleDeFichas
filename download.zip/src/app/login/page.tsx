"use client";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Link from "next/link";
import { FileSpreadsheet } from "lucide-react";

export default function LoginPage() {
  return (
    <main className="flex items-center justify-center min-h-screen bg-muted">
      <Card className="w-full max-w-sm shadow-lg">
        <CardHeader className="text-center">
            <div className="inline-block p-2 mx-auto mb-4 rounded-full bg-primary/10">
                <FileSpreadsheet className="w-8 h-8 text-primary" />
            </div>
          <CardTitle className="text-2xl">Controle de Fichas</CardTitle>
          <CardDescription>
            Entre com suas credenciais para acessar o painel.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" placeholder="m@exemplo.com" required />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="password">Senha</Label>
            <Input id="password" type="password" required />
          </div>
        </CardContent>
        <CardFooter>
            <Button className="w-full" asChild>
                <Link href="/">Entrar</Link>
            </Button>
        </CardFooter>
      </Card>
    </main>
  );
}
