"use client";

import { useState } from 'react';
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Truck, Store, Undo2, CheckCircle2, Clock, Trash2, Edit, XCircle, MoreVertical } from 'lucide-react';
import type { Ficha, Status } from '@/lib/types';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from './ui/dialog';
import { Label } from './ui/label';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

const statusConfig: Record<Status, { label: string; icon: React.ElementType; color: string }> = {
  na_loja: { label: 'Na Loja', icon: Store, color: '#6b7280' },
  em_rota: { label: 'Em Rota', icon: Truck, color: '#3b82f6' },
  devolvida: { label: 'Devolvida', icon: Undo2, color: '#f97316' },
  quitada: { label: 'Quitada', icon: CheckCircle2, color: '#22c55e' },
  agendada: { label: 'Agendada', icon: Clock, color: '#a855f7' },
  cancelada: { label: 'Cancelada', icon: XCircle, color: '#ef4444' },
};

type FichasTableProps = {
  fichas: Ficha[];
  onUpdateFicha: (ficha: Ficha) => void;
  onDeleteFicha: (id: string) => void;
};

export function FichasTable({ fichas, onUpdateFicha, onDeleteFicha }: FichasTableProps) {
  const [editingFicha, setEditingFicha] = useState<Ficha | null>(null);
  const [newObservation, setNewObservation] = useState('');

  const handleStatusChange = (ficha: Ficha, newStatus: Status) => {
    onUpdateFicha({ ...ficha, status: newStatus });
  };
  
  const handleEditObservation = (ficha: Ficha) => {
    setEditingFicha(ficha);
    setNewObservation(ficha.observations || '');
  };

  const handleSaveObservation = () => {
    if (editingFicha) {
      onUpdateFicha({ ...editingFicha, observations: newObservation });
      setEditingFicha(null);
      setNewObservation('');
    }
  };

  const ActionsMenu = ({ ficha }: { ficha: Ficha }) => (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <MoreVertical className="w-4 h-4" />
          <span className="sr-only">Ações</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuSub>
            <DropdownMenuSubTrigger>Mudar Status</DropdownMenuSubTrigger>
            <DropdownMenuSubContent>
                {Object.entries(statusConfig).map(([statusKey, status]) => {
                    const SubIcon = status.icon;
                    return (
                    <DropdownMenuItem key={status.label} onClick={() => handleStatusChange(ficha, statusKey as Status)}>
                        <SubIcon className="w-4 h-4 mr-2" />
                        {status.label}
                    </DropdownMenuItem>
                )})}
            </DropdownMenuSubContent>
        </DropdownMenuSub>
        <DropdownMenuItem onClick={() => handleEditObservation(ficha)}>
          <Edit className="w-4 h-4 mr-2" />
          Editar Observação
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-destructive focus:text-destructive">
              <Trash2 className="w-4 h-4 mr-2" />
              Excluir
            </DropdownMenuItem>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
              <AlertDialogDescription>
                Essa ação não pode ser desfeita. Isso excluirá permanentemente a ficha.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={() => onDeleteFicha(ficha.id)}>Excluir</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </DropdownMenuContent>
    </DropdownMenu>
  );

  return (
    <>
      {/* Desktop View */}
      <div className="hidden md:block border rounded-lg shadow-sm bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[100px]">Código</TableHead>
              <TableHead>Nome do Cliente</TableHead>
              <TableHead>Data Criação</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Observações</TableHead>
              <TableHead className="text-right w-[80px]">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {fichas.length > 0 ? (
              fichas.map((ficha, index) => {
                const StatusIcon = statusConfig[ficha.status].icon;
                return (
                <TableRow key={ficha.id} className={cn(index % 2 !== 0 && 'bg-muted/50')}>
                  <TableCell className="font-medium">{ficha.customerCode}</TableCell>
                  <TableCell>{ficha.customerName}</TableCell>
                  <TableCell>{format(ficha.creationDate, 'dd/MM/yyyy', { locale: ptBR })}</TableCell>
                  <TableCell>
                    <Badge className="text-white hover:bg-opacity-80" style={{backgroundColor: statusConfig[ficha.status].color}}>
                      <StatusIcon className="w-3.5 h-3.5 mr-1.5" />
                      {statusConfig[ficha.status].label}
                    </Badge>
                  </TableCell>
                  <TableCell className="max-w-xs truncate" title={ficha.observations}>{ficha.observations}</TableCell>
                  <TableCell className="text-right">
                    <ActionsMenu ficha={ficha} />
                  </TableCell>
                </TableRow>
              )})
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center">
                  Nenhuma ficha encontrada para esta data.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

       {/* Mobile View */}
       <div className="grid gap-4 md:hidden">
        {fichas.length > 0 ? (
          fichas.map((ficha) => {
            const StatusIcon = statusConfig[ficha.status].icon;
            return (
              <Card key={ficha.id} className="shadow-md">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{ficha.customerName}</CardTitle>
                    <ActionsMenu ficha={ficha} />
                  </div>
                  <p className="text-sm text-muted-foreground">Código: {ficha.customerCode}</p>
                </CardHeader>
                <CardContent className="grid gap-2 text-sm">
                  <div>
                    <span className="font-semibold">Data: </span>
                    {format(ficha.creationDate, 'dd/MM/yyyy', { locale: ptBR })}
                  </div>
                  <div className="flex items-center">
                    <span className="font-semibold mr-2">Status: </span>
                    <Badge className="text-white" style={{ backgroundColor: statusConfig[ficha.status].color }}>
                      <StatusIcon className="w-3.5 h-3.5 mr-1.5" />
                      {statusConfig[ficha.status].label}
                    </Badge>
                  </div>
                  {ficha.observations && (
                    <div>
                      <p className="font-semibold">Observações:</p>
                      <p className="text-muted-foreground truncate" title={ficha.observations}>{ficha.observations}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })
        ) : (
          <div className="text-center text-muted-foreground py-12">
            Nenhuma ficha encontrada para esta data.
          </div>
        )}
      </div>

      <Dialog open={!!editingFicha} onOpenChange={(open) => !open && setEditingFicha(null)}>
        <DialogContent>
            <DialogHeader>
                <DialogTitle>Editar Observação</DialogTitle>
            </DialogHeader>
            <div className="py-4">
                <Label htmlFor="observation">Observação</Label>
                <Textarea
                    id="observation"
                    value={newObservation}
                    onChange={(e) => setNewObservation(e.target.value)}
                    className="mt-2"
                    rows={4}
                />
            </div>
            <DialogFooter>
                <DialogClose asChild>
                    <Button variant="outline">Cancelar</Button>
                </DialogClose>
                <Button onClick={handleSaveObservation}>Salvar</Button>
            </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
