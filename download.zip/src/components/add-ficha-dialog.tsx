"use client";

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import type { Customer, Ficha } from '@/lib/types';
import { PlusCircle } from 'lucide-react';

const fichaSchema = z.object({
  customerCode: z.string().min(1, 'Código é obrigatório.'),
  customerName: z.string().min(1, 'Nome é obrigatório.'),
  observations: z.string().optional(),
  status: z.enum(['na_loja', 'em_rota', 'devolvida', 'quitada', 'agendada', 'cancelada']).default('na_loja'),
});

type FichaFormData = z.infer<typeof fichaSchema>;

type AddFichaDialogProps = {
  customers: Customer[];
  onAddFicha: (ficha: Omit<Ficha, 'id' | 'creationDate'>) => void;
};

export function AddFichaDialog({ customers, onAddFicha }: AddFichaDialogProps) {
  const [open, setOpen] = useState(false);
  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm<FichaFormData>({
    resolver: zodResolver(fichaSchema),
  });

  const handleCodeBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const code = e.target.value;
    const customer = customers.find((c) => c.code === code);
    if (customer) {
      setValue('customerName', customer.name, { shouldValidate: true });
    }
  };

  const onSubmit = (data: FichaFormData) => {
    onAddFicha(data);
    reset();
    setOpen(false);
  };
  
  const handleOpenChange = (isOpen: boolean) => {
    if (!isOpen) {
      reset();
    }
    setOpen(isOpen);
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button>
          <PlusCircle className="mr-2 h-4 w-4" />
          Nova Ficha
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Adicionar Nova Ficha</DialogTitle>
          <DialogDescription>
            Preencha os detalhes da ficha. Clique em salvar para concluir.
          </DialogDescription>
        </DialogHeader>
        <form id="add-ficha-form" onSubmit={handleSubmit(onSubmit)} className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="customerCode" className="text-right">
              Código
            </Label>
            <div className="col-span-3">
              <Input
                id="customerCode"
                {...register('customerCode')}
                onBlur={handleCodeBlur}
                className="w-full"
              />
              {errors.customerCode && (
                <p className="text-sm text-destructive mt-1">{errors.customerCode.message}</p>
              )}
            </div>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="customerName" className="text-right">
              Nome
            </Label>
            <div className="col-span-3">
              <Input
                id="customerName"
                {...register('customerName')}
                className="w-full"
              />
              {errors.customerName && (
                <p className="text-sm text-destructive mt-1">{errors.customerName.message}</p>
              )}
            </div>
          </div>
          <div className="grid grid-cols-4 items-start gap-4">
            <Label htmlFor="observations" className="text-right pt-2">
              Observações
            </Label>
            <Textarea
              id="observations"
              {...register('observations')}
              className="col-span-3"
              rows={3}
            />
          </div>
        </form>
        <DialogFooter>
            <DialogClose asChild>
                <Button type="button" variant="outline">Cancelar</Button>
            </DialogClose>
            <Button type="submit" form="add-ficha-form">Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
